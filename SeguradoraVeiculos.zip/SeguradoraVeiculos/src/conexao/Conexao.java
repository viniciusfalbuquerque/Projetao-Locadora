/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class Conexao {
    
    private static Connection conexao;
    
    public static Connection conexaoDB(){
        if(conexao == null){
            try {
           ;     
                String DB = "jdbc:mysql://localhost:3306/locadora_veiculo";
                String user = "root";
                String pass = "";
                
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                conexao = (Connection) DriverManager.getConnection(DB, user, pass);
                
                
            } catch (Exception e) {
                
                JOptionPane.showMessageDialog(null, "Problema de conexão com o Banco de Dados!");
                
            }
        }
        
        return conexao;
    }
    
}
