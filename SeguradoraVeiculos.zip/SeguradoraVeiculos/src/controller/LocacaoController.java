/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.HeadlessException;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Locacao;


public class LocacaoController {
     
    public void verificarSeAtualizaOuInsere(boolean data, Locacao locacao){
        
        if(data==true){
            try {
                String sql = "insert into locacoes values('"+locacao.getIdLocacao()+"','"+locacao.getCliente().getIdCliente()+"','"+locacao.getVeiculo().getIdVeiculo()+"','"+locacao.getDt_devolucao()+"','"+locacao.getValor_locacao()+"')";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Salvo com sucesso!");
                
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            
        } else {
            
            try {
                String sql = "update locacoes set idCliente = '"+locacao.getCliente().getIdCliente()+"', idVeiculo = '"+locacao.getVeiculo().getIdVeiculo()+"', dt_devolucao = '"+locacao.getDt_devolucao()+"', valor_locacao = '"+locacao.getValor_locacao()+"' where idLocacao='"+locacao.getIdLocacao()+"'";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Atualizado com sucesso!");
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
              
        }
    }
    
    public void excluir(boolean data, Locacao locacao){
        
        try {
                String sql = "delete from locacoes where idLocacao='"+locacao.getIdLocacao()+"'";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Excluido com sucesso!");
                data=true;
                
                
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
        
    }
    
    
    
}
