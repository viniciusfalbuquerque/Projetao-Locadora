/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.HeadlessException;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Seguro;

public class SeguroController {
    
    public void verificarSeAtualizaOuInsere(boolean data, Seguro seguro){
        
        if(data==true){
            try {
                String sql = "insert into seguros values('"+seguro.getIdSeguro()+"','"+seguro.getCliente().getIdCliente()+"','"+seguro.getVeiculo().getIdVeiculo()+"','"+seguro.getApolice()+"','"+seguro.getCarroReserva()+"','"+seguro.getQtdDiasCarroReserva()+"')";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Salvo com sucesso!");
                
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            
        } else {
            
            try {
                String sql = "update seguros set idCliente = '"+seguro.getCliente().getIdCliente()+"', idVeiculo = '"+seguro.getVeiculo().getIdVeiculo()+"', apolice = '"+seguro.getApolice()+"', carroReserva = '"+seguro.getCarroReserva()+"', qtdDiasCarroReserva = '"+seguro.getQtdDiasCarroReserva()+"' where idSeguro='"+seguro.getIdSeguro()+"'";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Atualizado com sucesso!");
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
              
        }
    }
    
    public void excluir(boolean data, Seguro seguro){
        
        try {
                String sql = "delete from seguros where idSeguro='"+seguro.getIdSeguro()+"'";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Excluido com sucesso!");
                data=true;
                
                
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
        
    }
    
    
}
