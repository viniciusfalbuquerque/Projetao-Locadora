/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.HeadlessException;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Veiculo;

public class VeiculoController {
    
    public void verificarSeAtualizaOuInsere(boolean data, Veiculo veiculo){
        
        if(data==true){
            try {
                String sql = "insert into veiculos values('"+veiculo.getIdVeiculo()+"','"+veiculo.getModelo()+"','"+veiculo.getCor()+"','"+veiculo.getChassis()+"','"+veiculo.getAno()+"','"+veiculo.getPlaca()+"','"+veiculo.getKm()+"')";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Salvo com sucesso!");
                
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            
        } else {
            
            try {
                String sql = "update veiculos set modelo = '"+veiculo.getModelo()+"', placa = '"+veiculo.getPlaca()+"', cor = '"+veiculo.getCor()+"', ano = '"+veiculo.getAno()+"', chassis = '"+veiculo.getChassis()+"', km = '"+veiculo.getKm()+"'  where idVeiculo='"+veiculo.getIdVeiculo()+"'";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Atualizado com sucesso!");
            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }
              
        }
    }
    
    public void excluir(boolean data, Veiculo veiculo){
        
        try {
                String sql = "delete from veiculos where idVeiculo='"+veiculo.getIdVeiculo()+"'";
                java.sql.Connection conn = (java.sql.Connection)conexao.Conexao.conexaoDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Registro Excluido com sucesso!");
                data=true;
                
                
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
        
    }
    
    
}
