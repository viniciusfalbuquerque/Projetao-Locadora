/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

public class Seguro {
 
    private int idSeguro;
    private Cliente cliente;
    private Veiculo Veiculo;
    private String apolice;
    private char carroReserva;
    private int qtdDiasCarroReserva;

    /**
     * @return the idSeguro
     */
    public int getIdSeguro() {
        return idSeguro;
    }

    /**
     * @param idSeguro the idSeguro to set
     */
    public void setIdSeguro(int idSeguro) {
        this.idSeguro = idSeguro;
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the Veiculo
     */
    public Veiculo getVeiculo() {
        return Veiculo;
    }

    /**
     * @param Veiculo the Veiculo to set
     */
    public void setVeiculo(Veiculo Veiculo) {
        this.Veiculo = Veiculo;
    }

    /**
     * @return the apolice
     */
    public String getApolice() {
        return apolice;
    }

    /**
     * @param apolice the apolice to set
     */
    public void setApolice(String apolice) {
        this.apolice = apolice;
    }

    /**
     * @return the carroReserva
     */
    public char getCarroReserva() {
        return carroReserva;
    }

    /**
     * @param carroReserva the carroReserva to set
     */
    public void setCarroReserva(char carroReserva) {
        this.carroReserva = carroReserva;
    }

    /**
     * @return the qtdDiasCarroReserva
     */
    public int getQtdDiasCarroReserva() {
        return qtdDiasCarroReserva;
    }

    /**
     * @param qtdDiasCarroReserva the qtdDiasCarroReserva to set
     */
    public void setQtdDiasCarroReserva(int qtdDiasCarroReserva) {
        this.qtdDiasCarroReserva = qtdDiasCarroReserva;
    }
    
    
}
