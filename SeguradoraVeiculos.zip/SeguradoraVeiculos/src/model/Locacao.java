/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

public class Locacao {
    
    private int idLocacao;
    private Cliente cliente;
    private Veiculo veiculo;
    private String dt_devolucao;
    private Double valor_locacao;

    /**
     * @return the idLocacao
     */
    public int getIdLocacao() {
        return idLocacao;
    }

    /**
     * @param idLocacao the idLocacao to set
     */
    public void setIdLocacao(int idLocacao) {
        this.idLocacao = idLocacao;
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the veiculo
     */
    public Veiculo getVeiculo() {
        return veiculo;
    }

    /**
     * @param veiculo the veiculo to set
     */
    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    /**
     * @return the dt_devolucao
     */
    public String getDt_devolucao() {
        return dt_devolucao;
    }

    /**
     * @param dt_devolucao the dt_devolucao to set
     */
    public void setDt_devolucao(String dt_devolucao) {
        this.dt_devolucao = dt_devolucao;
    }

    /**
     * @return the valor_locacao
     */
    public Double getValor_locacao() {
        return valor_locacao;
    }

    /**
     * @param valor_locacao the valor_locacao to set
     */
    public void setValor_locacao(Double valor_locacao) {
        this.valor_locacao = valor_locacao;
    }
    
    
    
}
